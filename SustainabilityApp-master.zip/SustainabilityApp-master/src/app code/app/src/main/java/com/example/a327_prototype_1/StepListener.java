package com.example.a327_prototype_1;

// Will listen to step alerts
public interface StepListener {
    public void step(long timeNs);
}
